#!/bin/bash

echo "enter num"
read n
ze=0
sum=0
num=$n
while [ $n -gt $ze ]
do 
    r=$(($n%10))
    c=$(($r * $r * $r))
    sum=$(($sum + $c))

    n=$(($n/10))
done

if [ $sum == $num ]
then
    echo "Yes"
else
    echo "No"
fi
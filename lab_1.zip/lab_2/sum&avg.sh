#!/bin/bash

echo "enter 10 nums"

sum=0

for i in {1..10}
do
    read x
    sum=$(($sum + $x))
done

echo "sum of nums is $sum"
echo ""
echo "avg is $(echo $sum/10 | bc -l)"
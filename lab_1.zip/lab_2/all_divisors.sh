#!/bin/bash

echo "enter num"
read num
ans="1"
for ((i=2; i <= num;i++))
do
    if [ $((num % i)) == 0 ]
    then        
        ans="$ans $i"
    fi
done

echo -e "all divisors of $num are \n$ans"
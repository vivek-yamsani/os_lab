echo "enter the string"
read s
length=${#s}
count=0
for ((i=0;i<$length;i++))
do
    echo "${s:$i:1}"
    if [[ ${s:$i:1} == 'a' ]] || [[ ${s:$i:1} == "e" ]] || [[ ${s:$i:1} == 'i' ]] ||  [[ ${s:$i:1} == "o" ]] || [[ ${s:$i:1} == 'u' ]]
    then
        count=$((count+1))
    fi
done
echo "no of vowels are $count in '$s'"


#!/bin/bash

echo "enter string "
read string

length=${#string}
ans=""
for ((i=$length-1; i>=0; i--))
do
    ans="${ans}${string:$i:1}"
done

echo "reversed string is ${ans}"
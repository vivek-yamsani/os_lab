#!/bin/bash

echo "enter string"
read string

count=$(echo $string | grep -io [aeiou] | wc -l)
echo "no of vowels are $count in '$string'"

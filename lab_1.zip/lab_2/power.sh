#!/bin/bash

echo "enter x"
read x
echo "enter n"
read n

ans=1

if [ $n -lt 0 ]
then
	echo "$n is < 0";
	exit;
fi

for((i=1;i<=$n;i++))
do
	ans=$(($ans*$x))
done

echo "$x ^ $n = $ans"

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>

int main()
{
    pid_t p2, p3, p4, p5;
    int c = 0;
    (p2 = fork()) && (p3 = fork());
    if (p2 == 0)
    {
        printf("P2:\nPid: %d \nppid: %d \n", getpid(), getppid());
    }
    else if (p3 == 0)
    {
        (p4 = fork()) && (p5 = fork());
        if (p4 == 0)
        {
            printf("P4:\nPid: %d \nppid: %d \n", getpid(), getppid());
        }
        else if (p5 == 0)
        {
            printf("P5:\nPid: %d \nppid: %d \n", getpid(), getppid());
        }
        else
        {
            // sleep(0.05);
            wait(NULL);
            wait(NULL);
            printf("P3:\nPid: %d \nppid: %d \n", getpid(), getppid());
        }
    }
    else
    {

        wait(NULL);
        wait(NULL);
        printf("P1:\nPid: %d \n", getpid());
    }

    return 0;
}
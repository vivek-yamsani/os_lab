#include <bits/stdc++.h>
#include <unistd.h>
#include <sys/wait.h>
using namespace std;

int main()
{
    pid_t p2, p3, p4, p5;
    int c = 0;
    (p2 = fork()) && (p3 = fork());
    if (p2 == 0)
    {
        cout << "P2:\nPid:" << getpid() << "\nppid:" << getppid() << endl;
    }
    else if (p3 == 0)
    {
        (p4 = fork()) && (p5 = fork());
        if (p4 == 0)
        {
            cout << "P4:\nPid:" << getpid() << "\nppid:" << getppid() << endl;
        }
        else if (p5 == 0)
        {
            cout << "P5:\nPid:" << getpid() << "\nppid:" << getppid() << endl;
        }
        else
        {
            // sleep(0.05);
            wait(NULL);
            wait(NULL);
            cout << "P3:\nPid:" << getpid() << "\nppid:" << getppid() << endl;
        }
    }
    else
    {

        wait(NULL);
        wait(NULL);
        cout << "P1:\nPid:" << getpid() << endl;
    }

    return 0;
}
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char *argv[])
{
    if (argc != 2)
    {
        exit(1);
    }
    int fd, count;
    char buffer[2048];
    fd = open(argv[1], O_RDONLY);
    if (fd == -1)
    {
        printf("cannot open file");
        exit(1);
    }
    while ((count = read(fd, buffer, sizeof(buffer))) > 0)
    {
        printf("%s", buffer);
    }
    exit(0);
}

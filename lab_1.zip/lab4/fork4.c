#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
#define MAX 100

int main()
{
    int fd[2];
    pipe(fd);
    pid_t pid = fork();
    if (pid == 0)
    {
        printf("Enter n: ");
        int n;
        scanf("%d", &n);
        char a[n + 1];
        printf("Enter the characters: ");
        scanf("%s", a);

        write(fd[1], a, sizeof(a));
    }
    else if (pid > 0)
    {
        wait(NULL);
        char arr[MAX];

        int n = read(fd[0], arr, sizeof(arr)), count = 0;
        for (int i = 0; i < n; i++)
        {
            if (arr[i] == 'a' || arr[i] == 'e' || arr[i] == 'i' || arr[i] == 'o' || arr[i] == 'u')
                count++;
        }
        printf("Number of Vowels = %d\n", count);
    }
    else
    {
        perror("error\n");
    }
}
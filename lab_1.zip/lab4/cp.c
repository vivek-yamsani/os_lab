#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
int cpy(char *, char *);

int cpy(char *fnDest, char *fnSrc)
{
    FILE *fpDest, *fpSrc;
    int c;

    if ((fpDest = fopen(fnDest, "w")) && (fpSrc = fopen(fnSrc, "r")))
    {
        while ((c = getc(fpSrc)) != EOF)
            putc(c, fpDest);
        fclose(fpDest);
        fclose(fpSrc);

        return 0;
    }
    return -1;
}

int main(int argc, char *argv[])
{
    if (argc != 3)
    {
        printf("Incorrect arguments .. \n");
        exit(1);
    }
    char *f1 = argv[1];
    char *f2 = argv[2];
    if (cpy(f2, f1) == -1)
    {
        printf("Failed...\n");
    }
    return 0;
}

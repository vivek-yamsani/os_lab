#include <iostream>
#include <climits>
#include <unordered_set>
#include <vector>
using namespace std;

int main()
{
    vector<int> frames(4, -1);
    vector<int> p;
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
    {
        int dummy;
        cin >> dummy;
        p.push_back(dummy);
    }
    int pf = 0;
    for (int i = 0; i < n; i++)
    {
        cout << endl
             << "page considered:" << p[i] << endl;
        bool already_present_in_frame = false;
        int index = -1;
        for (int j = 0; j < 4; j++)
        {
            if (frames[j] == -1)
            {
                index = j;
            }
            if (frames[j] == p[i])
            {
                already_present_in_frame = true;
                break;
            }
        }
        if (!already_present_in_frame)
        {
            pf++;
            if (index >= 0)
            {
                frames[index] = p[i];
                continue;
            }
            unordered_set<int> s;
            for (int i : frames)
                s.insert(i);
            for (int j = i + 1; j < n && s.size() > 1; j++)
            {
                if (s.count(p[i]))
                    s.erase(p[i]);
            }
        }
        for (int i = 0; i < 4; i++)
            cout << frames[i] << " ";
        cout << endl;
    }
    cout << "No. of page faults:" << pf << endl;
    return 0;
}
// 3 2 1 2 3 6 4 7 2 3 4 2 1 5 7 6 2 6 2 2 3 3
#include <iostream>
#include <vector>
using namespace std;

int main()
{
    int n, m;
    cin >> n >> m;
    int max_demand[n][m], allocation[n][m], available[m], need[n][m];
    vector<bool> finish(n, false);
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> allocation[i][j];
        }
    }
    for (int i = 0; i < n; i++)
    {
        for (int j = 0; j < m; j++)
        {
            cin >> max_demand[i][j];
            need[i][j] = max_demand[i][j] - allocation[i][j];
        }
    }
    for (int i = 0; i < m; i++)
        cin >> available[i];

    vector<int> safeSequence;
    int it = 0;
    while (true)
    {
        int allocatable_process = -1;
        for (int i = 0; i < n; i++)
        {
            if (finish[it % n])
            {
                it++;
                continue;
            }
            bool isAllocatable = true;
            for (int j = 0; j < m; j++)
            {
                if (need[it % n][j] > available[j])
                {
                    isAllocatable = false;
                    break;
                }
            }
            if (isAllocatable)
            {
                allocatable_process = it;
                break;
            }
            it++;
        }
        if (allocatable_process == -1)
            break;
        for (int i = 0; i < m; i++)
        {
            available[i] += allocation[allocatable_process % n][i];
        }
        safeSequence.push_back(allocatable_process % n);
        finish[allocatable_process % n] = true;
        it++;
    }
    cout << (safeSequence.size() == n ? "SAFE STATE\n" : "UNSAFE STATE\n");
    if (safeSequence.size() == n)
    {
        for (int i : safeSequence)
            cout << i << " ";

        cout << "\n";
    }
}
/*
5 3
0 1 0
2 0 0
3 0 2
2 1 1
0 0 2

7 5 3
3 2 2
9 0 2
2 2 2
4 3 3

3 3 2
*/
#include <iostream>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
using namespace std;

int main()
{
    int pid = fork();
    if (pid == 0)
    {
        cout << "Child Process start\n";
        cout << "Enter No of charcters : ";
        int n;
        cin >> n;
        cout << "Enter the String : ";
        char s[n + 1];
        read(STDIN_FILENO, s, n);
        int shm_id = shmget((key_t)1234, 1024, 0666 | IPC_CREAT);
        char *shared_memory = (char *)shmat(shm_id, NULL, 0);
        strcpy(shared_memory, s);
        cout << "Child Process end\n\n";
    }
    else
    {
        wait(NULL);
        cout << "Parent Process start\n";
        int shm_id = shmget((key_t)1234, 1024, 0666);
        char *shared_memory = (char *)shmat(shm_id, NULL, 0);
        int no_of_vowels = 0;
        for (int i = 0; i < strlen(shared_memory); i++)
        {
            switch (shared_memory[i])
            {
            case 'a':
                no_of_vowels++;
                break;
            case 'e':
                no_of_vowels++;
                break;
            case 'i':
                no_of_vowels++;
                break;
            case 'o':
                no_of_vowels++;
                break;
            case 'u':
                no_of_vowels++;
                break;
            }
        }
        cout << "No of vowels in the string : " << shared_memory << "\nare " << no_of_vowels << "\n";
        cout << "Parent Process end\n\n";
    }

    return 0;
}
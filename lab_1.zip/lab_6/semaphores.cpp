#include <pthread.h>
#include <unistd.h>
#include <iostream>
#include <semaphore.h>
using namespace std;

int account_balance = 11000;
sem_t semaphore;

void *deposit(void *arg)
{
    sem_wait(&semaphore);
    cout << "Deposit start \n";
    cout << "Account Balance now : " << account_balance << "\n";
    account_balance += 5000;
    sleep(2);
    cout << "Account Balance now : " << account_balance << "\n";
    cout << "Deposit end\n";
    sem_post(&semaphore);

    return (void *)0;
}

auto with_draw = [](void *arg)
{
    sem_wait(&semaphore);
    cout << "Withdrawal start \n";
    cout << "Account Balance now : " << account_balance << "\n";
    account_balance -= 2000;
    sleep(2);
    cout << "Account Balance now : " << account_balance << "\n";
    cout << "Withdrawal end\n";
    sem_post(&semaphore);

    return (void *)0;
};

int main()
{
    sem_init(&semaphore, 0, 1);

    pthread_t X, Y;
    cout << "Account Balance now : " << account_balance << "\n";
    pthread_create(&X, NULL, deposit, NULL);
    pthread_create(&Y, NULL, with_draw, NULL);
    pthread_join(X, NULL);
    pthread_join(Y, NULL);
    cout << "Account Balance now : " << account_balance << "\n";
}
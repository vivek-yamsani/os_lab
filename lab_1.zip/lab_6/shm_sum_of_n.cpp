#include <iostream>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/wait.h>
#include <unistd.h>
#include <string.h>
using namespace std;

int main()
{
    key_t key = ftok("./shm_sum_of_n.cpp", 1234);
    int pid = fork();
    if (pid == 0)
    {
        cout << "Child Process start\n";
        cout << "Enter No of elements : ";
        int n;
        cin >> n;
        cout << "Enter the nums : ";
        int arr[n + 1];
        arr[0] = n;
        for (int i = 1; i <= n; i++)
            cin >> arr[i];
        int shm_id = shmget(key, 1000, 0666 | IPC_CREAT);
        int *shared_memory = (int *)shmat(shm_id, NULL, 0);
        for (int i = 0; i <= n; i++)
            shared_memory[i] = arr[i];
        cout << "Child Process end\n\n";
    }
    else
    {
        wait(NULL);
        cout << "Parent Process start\n";
        int shm_id = shmget(key, 1000, 0666);
        int *shared_memory = (int *)shmat(shm_id, NULL, 0);
        int sum = 0, n = shared_memory[0];
        for (int i = 1; i <= n; i++)
        {
            cout << shared_memory[i] << " ";
            sum += shared_memory[i];
        }
        cout << "\n";
        cout << "Sum of N integers : " << sum << "\n";
        cout << "Parent Process end\n\n";
    }

    return 0;
}
#!/bin/bash

ls -lS | head -2 | tail -1 | awk '{print $9}'

#!/bin/bash

echo "enter the user name : "
read user
if [ "$user" = "$(whoami)" ]
then
echo "logged in"
else
echo "not logged in"
fi


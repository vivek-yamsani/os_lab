#!/bin/bash

ls -l | awk '(NR>1){print $5}' > temp


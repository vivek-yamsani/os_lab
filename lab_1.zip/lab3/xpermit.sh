#!/bin/bash

echo "enter the file name: "
read file
if [ -e $file ]
then
if [ -x $file ]
then
echo "it is an executable"
else
echo "it is an non-executable"
fi
else
echo "no such file named $file "
fi


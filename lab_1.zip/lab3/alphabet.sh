#!/bin/bash

echo "enter an alphabet: "
read char
ls $char*
